<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\CmsPage;

class CmsPageTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $cmsPagesRecords=[
            ['id'=>1,'name'=>'About Us','contact'=>'Content is comming soon','vehicle'=>'about-us'
             ,'purpose'=>'About Us','status'=>1],
            
        ];
        CmsPage::insert($cmsPagesRecords);
    }
}
