@extends('admin.layout')
@section("content")

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1> Visitor Page</h1>
          </div>
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Visitor Page</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
              </button>
              <button type="button" class="btn btn-tool" data-card-widget="remove">
                <i class="fas fa-times"></i>
              </button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">
              <div class="col-12">
              @if($errors->any())
<div class="alert alert-danger">
  <ul>
    @foreach($errors->all() as $error)
    <li>{{$error}}</li>
    @endforeach
    <ul>
</div>
@endif
              <form name="cmsForm" id="cmsForm" @if(empty($cmspage['id'])) action="{{url('admin/add-edit-cms-page')}}"
               @else action="{{url('admin/add-edit-cms-page/'.$cmspage['id'])}}" @endif method="post">@csrf
                <div class="card-body">
                  <div class="form-group">
                    <label for="name">Name*</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder=
                    "Enter Name" @if(!empty($cmspage['name'])) value="{{$cmspage['name']}}"
                    @endif>
                  </div>
                  <div class="form-group">
                    <label for="contact">Contact No.*</label>
                    <input type="text" class="form-control" id="contact" name="contact" placeholder=
                    "Enter Contact No."  @if(!empty($cmspage['contact'])) value="{{$cmspage['contact']}}"
                    @endif>
                  </div>
                
                <div class="form-group">
                    <label for="vehicle">Vehicle or Walk-in</label>
                    <input type="text" class="form-control" id="vehicle" name="vehicle" placeholder=
                    "Enter Vehicle"  @if(!empty($cmspage['vehicle'])) value="{{$cmspage['vehicle']}}"
                    @endif>
                  </div>
                  <div class="form-group">
                    <label for="purpose">Purpose of Visit</label>
                    <input type="text" class="form-control" id="purpose" name="purpose" placeholder=
                    "Enter Purpose"  @if(!empty($cmspage['purpose'])) value="{{$cmspage['purpose']}}"
                    @endif>
                  </div>
                  
                <!-- /.card-body -->

               
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          <!-- /.card-body -->
          <div class="card-footer">
        
          </div>
        </div>
        <!-- /.card -->

       
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection