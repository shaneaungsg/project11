<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CmsPage;
use Illuminate\Http\Request;
use League\CommonMark\Extension\DescriptionList\Node\Description;
use Session;

class CmsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {  Session::put('page','cms-pages');
        $CmsPages=CmsPage::get()->toArray();
       // dd($CmsPages);
       return view('admin.pages.cms_pages')->with(compact('CmsPages'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CmsPage $cmsPage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request, $id=null)
    {
        Session::put('page','cms-pages');
        if($id==""){
            $name="Add Visitor Page";
            $cmspage= new CmsPage;
            $message="Visitor Page added successfully";

        }else{

            $name="Edit Visitor Page";
            $cmspage= CmsPage::find($id);
            $message="Visitor Page updated successfully";
        }

        if($request->isMethod('post')){
            $data=$request->all();
           // echo "<pre>"; print_r($data);die;
            //cms pages validations
            $rules=[
                'name'=>'required',
                'contact'=>'required',
               // 'description'=>'required',

            ];
            $customMessage=[
                'name.required'=>'Name is required',
                'contact.required'=>'Contact No. is required',
                //'description.required'=>'Page Description is required',
            ];
            $this->validate($request,$rules,$customMessage);

            $cmspage->name=$data['name'];
            $cmspage->contact=$data['contact'];
            $cmspage->vehicle=$data['vehicle'];
            $cmspage->purpose=$data['purpose'];
            $cmspage->status=1;
            $cmspage->save();
            return redirect('admin/cms-pages')->with('success_message',$message);

        }


        return view("admin.pages.add_edit_cmspage")->with(compact('name','cmspage'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CmsPage $cmsPage)
    { //echo "test";die;
        if($request->ajax()){
            $data=$request->all();
            if($data['status']=="Active"){
                $status=0;
            }else{
                $status=1;
            }
            CmsPage::where('id',$data['page_id'])->update(['status'=>$status]);
            return response()->json(['status'=>$status,'page_id'=>$data['page_id']]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //delete cms page
        CmsPage::where('id',$id)->delete();
        return redirect()->back()->with('success_message','Selected visitor deleted successfully!');
    }
}
