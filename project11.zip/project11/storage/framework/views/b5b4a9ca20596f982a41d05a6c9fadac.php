<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
 

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
      <?php if(!empty(Auth::guard('admin')->user()->image)): ?>
        <img src="<?php echo e(asset('admin/img/photos/'
          .Auth::guard('admin')->user()->image)); ?>" class="img-circle elevation-2" alt="User Image">
      <?php else: ?>
      <img src="<?php echo e(asset('admin/img/no-image.png')); ?>" class="img-circle elevation-2" alt="User Image">


      <?php endif; ?>
      </div>
      <div class="info">
        <a href="#" class="d-block"><?php echo e(Auth::guard('admin')->user()->name); ?></a>
      </div>
    </div>

    <!-- SidebarSearch Form -->
   

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->
             <?php if(Session::get('page')=="cms-pages"): ?>
             <?php $active="active" ?>
             <?php else: ?>
             <?php $active="" ?>
             <?php endif; ?>
             <li class="nav-item">
          <a href="<?php echo e(url('admin/cms-pages')); ?>" class="nav-link <?php echo e($active); ?>">
            <i class="nav-icon fas fa-th"></i>
            <p>
              Dashboard
            
            </p>
          </a>
        </li>
        <?php if(Session::get('page')=="update_details"||Session::get('page')=="update_password"): ?>
             <?php $active="active" ?>
             <?php else: ?>
             <?php $active="" ?>
             <?php endif; ?>
        <li class="nav-item menu-open">
          <a href="#" class="nav-link <?php echo e($active); ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>
              Settings
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
          <?php if(Session::get('page')=="update_password"): ?>
             <?php $active="active" ?>
             <?php else: ?>
             <?php $active="" ?>
             <?php endif; ?>
            <li class="nav-item">
              <a href="<?php echo e(url('admin/update-password')); ?>" class="nav-link <?php echo e($active); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Update Admin Password  </p>
              </a>
            </li>
            <?php if(Session::get('page')=="update_details"): ?>
             <?php $active="active" ?>
             <?php else: ?>
             <?php $active="" ?>
             <?php endif; ?>
            <li class="nav-item">
              <a href="<?php echo e(url('admin/update-details')); ?>" class="nav-link <?php echo e($active); ?>">
                <i class="far fa-circle nav-icon"></i>
                <p>Update Admin Details</p>
              </a>
            </li>

           
          </ul>
        </li>
        
       
       
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\project11\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>