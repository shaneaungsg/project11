
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
            
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

     <!-- Main content -->
     <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
          <?php if(Session::has('success_message')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Dashboard</h3>
                <a style="max-width: 150px; float: right; display: inline-block;" href="<?php echo e(url
              ('admin/add-edit-cms-page')); ?>" class="btn btn-block btn-primary">Register New Visitor</a>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="cmspages" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Contact No.</th>
                    <th>Vehicle or Walk-in</th>
                    <th>Purpose of Visit</th>
                    <th>Updated at</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $CmsPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($page['id']); ?></td>
                    <td><?php echo e($page['name']); ?></td>
                    <td><?php echo e($page['contact']); ?></td>
                    <td><?php echo e($page['vehicle']); ?></td>
                    <td><?php echo e($page['purpose']); ?></td>
                    <td>  
                      <?php date_default_timezone_set('Asia/Singapore'); ?>
                      <?php echo e(date("F j, Y, g:i a", strtotime($page['updated_at']))); ?></td>
                    <td>
                      
                    <?php if($page['status']==1): ?>  
                    <a class="updateCmsPageStatus" id="page-<?php echo e($page['id']); ?>" page_id="<?php echo e($page['id']); ?>"
                    href="javascript:void(0)"><span style="color:#25be25;">Checkin </span> &nbsp;&nbsp;&nbsp;<i class="fas fa-toggle-on" style="color:#25be25;"  status="Active"></i></a>
                    <?php else: ?>
                    <a class="updateCmsPageStatus" id="page-<?php echo e($page['id']); ?>" page_id="<?php echo e($page['id']); ?>"
                    style="color:grey;" href="javascript:void(0)"><span style="color:grey;">Checkout </span> &nbsp;&nbsp;&nbsp;<i class="fas fa-toggle-off" status="Inactive"></i></a>
                 
                    <?php endif; ?>
                </td>
                <td>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a style="color:#3f6ed3;"  href="<?php echo e(url('admin/add-edit-cms-page/'.$page['id'])); ?>"><i class='fas fa-edit'></i></a>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a style="color:#3f6ed3;"  href="<?php echo e(url('admin/delete-cms-page/'.$page['id'])); ?>"><i class='fas fa-trash'></i></a>

                  </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project11\resources\views/admin/pages/cms_pages.blade.php ENDPATH**/ ?>