
<?php $__env->startSection("content"); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo e($title); ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><?php echo e($title); ?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title"><?php echo e($title); ?></h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
              </button>
              <button type="button" class="btn btn-tool" data-card-widget="remove">
                <i class="fas fa-times"></i>
              </button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">
              <div class="col-12">
              <?php if($errors->any()): ?>
<div class="alert alert-danger">
  <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <ul>
</div>
<?php endif; ?>
              <form name="cmsForm" id="cmsForm" <?php if(empty($cmspage['id'])): ?> action="<?php echo e(url('admin/add-edit-cms-page')); ?>"
               <?php else: ?> action="<?php echo e(url('admin/add-edit-cms-page/'.$cmspage['id'])); ?>" <?php endif; ?> method="post"><?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="title">Title*</label>
                    <input type="text" class="form-control" id="title" name="title" placeholder=
                    "Enter Page Title" <?php if(!empty($cmspage['title'])): ?> value="<?php echo e($cmspage['title']); ?>"
                    <?php endif; ?>>
                  </div>
                  <div class="form-group">
                    <label for="url">URL*</label>
                    <input type="text" class="form-control" id="url" name="url" placeholder=
                    "Enter Page URL"  <?php if(!empty($cmspage['url'])): ?> value="<?php echo e($cmspage['url']); ?>"
                    <?php endif; ?>>
                  </div>
                
                    <label for="description">Description*</label>
                    <textarea class="form-control" rows="3" id="description" name="description" 
                    placeholder="Enter Description"> <?php if(!empty($cmspage['description'])): ?> 
                    <?php echo e($cmspage['description']); ?> <?php endif; ?>
                </textarea>
                </div>
                <div class="form-group">
                    <label for="meta_title">Meta Title</label>
                    <input type="text" class="form-control" id="meta_title" name="meta_title" placeholder=
                    "Enter Meta Title"  <?php if(!empty($cmspage['meta_title'])): ?> value="<?php echo e($cmspage['meta_title']); ?>"
                    <?php endif; ?>>
                  </div>
                  <div class="form-group">
                    <label for="meta_description">Meta Description</label>
                    <input type="text" class="form-control" id="meta_description" name="meta_description" placeholder=
                    "Enter Meta Description"  <?php if(!empty($cmspage['meta_description'])): ?> value="<?php echo e($cmspage['meta_description']); ?>"
                    <?php endif; ?>>
                  </div>
                  <div class="form-group">
                    <label for="meta_keywords">Meta Keywords</label>
                    <input type="text" class="form-control" id="meta_keywords" name="meta_keywords" placeholder=
                    "Enter Meta Keywords"  <?php if(!empty($cmspage['meta_keywords'])): ?> value="<?php echo e($cmspage['meta_keywords']); ?>"
                    <?php endif; ?>>
                  </div>
                <!-- /.card-body -->

               
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          <!-- /.card-body -->
          <div class="card-footer">
        
          </div>
        </div>
        <!-- /.card -->

       
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project10\resources\views/admin/pages/add_edit_cmspage.blade.php ENDPATH**/ ?>