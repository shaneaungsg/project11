<!-- Main Footer -->
<footer class="main-footer">
  <strong>Copyright &copy; 2023 
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 1.0
  </div>
</footer>
<?php /**PATH C:\xampp\htdocs\project11\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>